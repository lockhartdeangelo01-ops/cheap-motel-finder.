# Cheap Motel Finder — free starter version

## What it does
- Mobile-friendly website that works in an iPhone browser.
- Lets the user type a city/ZIP or optionally share browser location.
- Opens Google Maps motel results and public search pages for Booking.com, Expedia, Hotels.com, KAYAK, and direct motel contact searches.
- Includes date, guest, room, and budget fields plus a before-you-book checklist.

## Important limitations
- This is a search helper, not a live hotel inventory system.
- It does not guarantee live prices, vacancies, taxes, deposits, or fees.
- Booking sites may change their URL formats and can ignore some search parameters.
- It does not take payments or make reservations.
- Location permission is optional; no location is sent anywhere except when you tap an external search link.

## Launch free on an iPhone using GitHub Pages
1. On your iPhone, open Safari and sign in to GitHub.
2. Create a new **public** repository named `cheap-motel-finder`.
3. Add the file `index.html` from this folder to the repository root. You can use GitHub's **Add file → Create new file** or upload the file.
4. Open the repository's **Settings → Pages**.
5. Under build/deployment, choose **Deploy from a branch**.
6. Choose branch `main` and folder `/ (root)`, then Save.
7. Wait for GitHub Pages to publish. Your site address will usually look like `https://YOUR-USERNAME.github.io/cheap-motel-finder/`.
8. Open the site in Safari. Tap **Share → Add to Home Screen** to make an app-like icon.

## Testing checklist
- Enter a city or ZIP code and open Maps results.
- Allow location access and verify the nearby search opens.
- Change dates and guest count and check that booking links update.
- Confirm rates and all fees on the provider's final checkout page before booking.

## Next upgrade ideas
- Add a trusted live inventory/price API (usually requires a provider account and may have commercial/affiliate terms).
- Add sorting/filtering only when verified price data is available.
- Add a server-backed favorites list or alerts if desired.
